<h1><span>Error</span></h1>
<div class="page-error">
Your session is closed
<br/>Please re-register 
</div>