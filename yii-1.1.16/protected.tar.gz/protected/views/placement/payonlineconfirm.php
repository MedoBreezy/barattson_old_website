<div class="progress-main page-5">
	<div class="step step-1 old">Registration form</div>
	<div class="step step-2 old">Payment Methods</div>
	<div class="step step-3 old">Order Details</div>
	<div class="step step-4 old">Payment process</div>
	<div class="step step-5 active">Confirmation</div>
</div>
<h1><span>Confirmation</span></h1>
<div class="confirmtext">
Thank you for your completion of payment process.
<br/>
You will receive the confirmation email regarding your payment approval.
<br/>
<br/>
Sincerely Your,
<br/>
<strong>Barattson</strong>
</div>