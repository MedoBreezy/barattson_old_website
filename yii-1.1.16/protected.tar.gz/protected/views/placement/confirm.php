<div class="progress-main page-5">
	<div class="step step-1 old">Registration form</div>
	<div class="step step-2 old">Payment Methods</div>
	<div class="step step-3 old">Important Notes</div>
	<div class="step step-4 old">Payment Invoice</div>
	<div class="step step-5 active">Confirmation</div>
</div>


<h1><span>Confirmation</span></h1>

<div class="confirmtext">
<strong>Dear Candidate!</strong>
<br/><br/>
Thank You for your completion of registration process.
<br/>
You will receive the confirmation <strong>e-mail</strong> regarding your completion of registration approval.
<br/>
We wish you success on your exams and hope you will pass to new level in your life.
<br/>
<br/>
Sincerely Your,
<br/>
<strong>Barattson</strong>
</div>
