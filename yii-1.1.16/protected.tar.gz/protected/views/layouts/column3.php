<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/client'); ?>
<div class="span-19">
	<div id="content">
		<?php echo $content; ?>
	</div><!-- content -->
</div>
<?php $this->endContent(); ?>
