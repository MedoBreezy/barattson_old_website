<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/print'); ?>
		<?php echo $content; ?>
<?php $this->endContent(); ?>
